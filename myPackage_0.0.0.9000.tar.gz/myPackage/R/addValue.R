#' @description A function that adds values.
#' @title a function that adds values
#' 
#' @param x one value
#' @param y another value
#' 
#' @examples 

addValue <- function(x,y){
  return(x+y)
}

